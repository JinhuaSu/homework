#! /bin/bash
hadoop fs -rm -r liuyang/wc_result

hadoop jar \
/opt/cloudera/parcels/CDH/lib/hadoop-mapreduce/hadoop-streaming.jar \
-input liuyang/hadoop.txt \
-output liuyang/wc_result \
-file "mapper.py" "reducer.py" \
-mapper "python3 mapper.py" \
-reducer "python3 reducer.py" \
-numReduceTasks 1


