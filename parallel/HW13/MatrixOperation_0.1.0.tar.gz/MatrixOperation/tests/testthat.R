library(testthat)
library(MatrixOperation)

test_check("MatrixOperation")
